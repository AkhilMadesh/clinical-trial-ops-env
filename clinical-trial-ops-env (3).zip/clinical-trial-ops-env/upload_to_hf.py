"""
Run this script to upload ALL project files to your HuggingFace Space.
It handles nested folders (env/, env/graders/, static/, tasks/) correctly.

Usage:
    pip install huggingface_hub
    python upload_to_hf.py
"""

import os
from huggingface_hub import HfApi

# ── CONFIG — change these 3 lines ─────────────────────────────────────────────
HF_TOKEN    = "your_hf_write_token_here"   # from huggingface.co/settings/tokens
HF_USERNAME = "akhil13-19"                 # your HF username
SPACE_NAME  = "clinical-trial-ops-env"     # your Space name
# ──────────────────────────────────────────────────────────────────────────────

REPO_ID = f"{HF_USERNAME}/{SPACE_NAME}"

api = HfApi(token=HF_TOKEN)

# All files to upload (relative paths)
FILES = [
    "Dockerfile",
    "README.md",
    "api.py",
    "inference.py",
    "openenv.yaml",
    "requirements.txt",
    ".gitignore",
    # env package
    "env/__init__.py",
    "env/models.py",
    "env/environment.py",
    "env/protocol_db.py",
    "env/case_generator.py",
    # graders
    "env/graders/__init__.py",
    "env/graders/eligibility.py",
    "env/graders/lab_dose.py",
    "env/graders/sae_triage.py",
    # tasks
    "tasks/task1_eligibility.yaml",
    "tasks/task2_lab_dose.yaml",
    "tasks/task3_sae_triage.yaml",
    # static landing page
    "static/index.html",
]

print(f"Uploading to: https://huggingface.co/spaces/{REPO_ID}")
print(f"Total files: {len(FILES)}\n")

for filepath in FILES:
    if not os.path.exists(filepath):
        print(f"  MISSING: {filepath}")
        continue
    try:
        api.upload_file(
            path_or_fileobj=filepath,
            path_in_repo=filepath,
            repo_id=REPO_ID,
            repo_type="space",
            commit_message=f"Add {filepath}",
        )
        print(f"  uploaded: {filepath}")
    except Exception as e:
        print(f"  ERROR {filepath}: {e}")

print("\nDone! Check your Space:")
print(f"  https://huggingface.co/spaces/{REPO_ID}")
print(f"  https://{HF_USERNAME}-{SPACE_NAME}.hf.space/health")
