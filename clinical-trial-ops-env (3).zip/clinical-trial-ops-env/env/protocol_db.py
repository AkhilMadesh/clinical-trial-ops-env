"""
ClinicalTrialOps-Env — Protocol Database
Fictional Phase II NSCLC trial: LUMINOS-201
Drug: Velitinib (fictional EGFR inhibitor)
"""

PROTOCOL = {
    "protocol_id": "LUMINOS-201",
    "version": "v3.1",
    "phase": "II",
    "indication": "Non-Small Cell Lung Cancer (NSCLC)",
    "drug": "Velitinib 150mg oral QD",

    "inclusion_criteria": [
        "Age >= 18 years",
        "Histologically confirmed NSCLC (adenocarcinoma or squamous)",
        "ECOG Performance Status 0-2",
        "Adequate hepatic function: ALT/AST <= 2.5x ULN (<=5x ULN if liver mets)",
        "Adequate renal function: creatinine <= 1.5x ULN OR eGFR >= 50 mL/min/1.73m2",
        "Adequate bone marrow: ANC >= 1.5x10^9/L, platelets >= 100x10^9/L, Hgb >= 9 g/dL",
        "Prior platinum-based chemotherapy (1-3 prior lines)",
        "Measurable disease per RECIST 1.1",
        "QTc <= 470ms (female) or <= 450ms (male) at baseline",
        "No prior EGFR-targeted therapy",
    ],

    "exclusion_criteria": [
        "Active uncontrolled infection",
        "Prior EGFR inhibitor therapy (erlotinib, gefitinib, osimertinib, etc.)",
        "Concurrent strong CYP3A4 inhibitors (ketoconazole, itraconazole, clarithromycin, etc.)",
        "ECOG Performance Status >= 3",
        "ALT or AST > 5x ULN",
        "creatinine > 1.5x ULN AND eGFR < 50",
        "ANC < 1.5x10^9/L or platelets < 100x10^9/L or Hgb < 9 g/dL",
        "QTc > 470ms (female) or > 450ms (male)",
        "Known hypersensitivity to velitinib or excipients",
        "Pregnancy or breastfeeding",
        "Active or prior interstitial lung disease",
        "Unstable cardiac condition (NYHA class III/IV) in past 6 months",
        "More than 3 prior lines of chemotherapy",
        "Symptomatic CNS metastases requiring steroids",
    ],

    "dose_modification_rules": {
        "hepatotoxicity": {
            "ALT_AST_grade2": {
                "threshold": "ALT or AST 3-5x ULN",
                "action": "dose_hold_temporary",
                "resume_criteria": "Return to <= 1x ULN",
                "max_holds": 2,
            },
            "ALT_AST_grade3": {
                "threshold": "ALT or AST 5-20x ULN",
                "action": "dose_reduce_1_level",
                "urgency": "24h",
            },
            "ALT_AST_grade4": {
                "threshold": "ALT or AST > 20x ULN",
                "action": "dose_discontinue",
                "urgency": "immediate",
                "report_SAE": True,
            },
        },
        "hematologic": {
            "ANC_grade3": {
                "threshold": "ANC 0.5-1.0 x10^9/L",
                "action": "dose_hold_temporary",
                "urgency": "24h",
            },
            "ANC_grade4": {
                "threshold": "ANC < 0.5 x10^9/L",
                "action": "dose_hold_temporary",
                "urgency": "immediate",
                "report_SAE": True,
            },
            "platelets_grade3": {
                "threshold": "Platelets 25-50 x10^9/L",
                "action": "dose_hold_temporary",
                "urgency": "24h",
            },
            "platelets_grade4": {
                "threshold": "Platelets < 25 x10^9/L",
                "action": "dose_hold_temporary",
                "urgency": "immediate",
                "report_SAE": True,
            },
        },
        "cardiac": {
            "QTc_prolongation": {
                "threshold": "QTc 470-500ms",
                "action": "dose_hold_temporary",
                "urgency": "24h",
            },
            "QTc_severe": {
                "threshold": "QTc > 500ms",
                "action": "dose_discontinue",
                "urgency": "immediate",
                "report_SAE": True,
            },
        },
        "renal": {
            "creatinine_grade2": {
                "threshold": "creatinine 1.5-3x ULN",
                "action": "dose_reduce_1_level",
                "urgency": "24h",
            },
        },
    },

    "sae_definitions": [
        "Death",
        "Life-threatening adverse event",
        "Hospitalization or prolonged hospitalization",
        "Persistent or significant disability/incapacity",
        "Congenital anomaly or birth defect",
        "Important medical event requiring intervention to prevent one of above",
    ],

    "reporting_requirements": {
        "SAE_unexpected_related": {
            "label": "SUSAR",
            "fda_window_days": 7,
            "fatal_or_life_threatening_window_days": 7,
            "sponsor_window_hours": 24,
            "regulation": "FDA 21 CFR 312.32(c)(1)",
        },
        "SAE_expected": {
            "fda_window_days": 15,
            "regulation": "FDA 21 CFR 312.32(c)(2)",
        },
        "protocol_deviation_major": {
            "irb_notification": True,
            "sponsor_notification": True,
            "regulation": "ICH E6 R2 Section 4.5",
        },
        "protocol_deviation_minor": {
            "document_in_source": True,
            "regulation": "ICH E6 R2 Section 4.5",
        },
    },

    "dose_levels": {
        "full": "150mg QD",
        "level_minus_1": "100mg QD",
        "level_minus_2": "75mg QD",
    },

    "strong_cyp3a4_inhibitors": [
        "ketoconazole", "itraconazole", "clarithromycin",
        "atazanavir", "indinavir", "nelfinavir", "ritonavir",
        "saquinavir", "telithromycin", "voriconazole",
        "posaconazole", "nefazodone",
    ],
}
