"""
ClinicalTrialOps-Env — Core Environment
Implements full OpenEnv spec: reset() / step() / state()
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import numpy as np

from env.models import Action, Observation, EnvState, RewardBreakdown
from env.case_generator import generate_cases
from env.graders import get_grader


@dataclass
class EnvConfig:
    task_id: str = "eligibility_screening"
    seed: int = 42


class ClinicalTrialEnv:
    """
    ClinicalTrialOps-Env: Phase II Oncology Trial Coordinator

    An AI agent acts as a clinical trial coordinator for the fictional
    LUMINOS-201 Phase II NSCLC study. Each episode is a shift batch of
    patient cases requiring decisions on eligibility, dose management,
    or adverse event reporting.

    API:
        reset() -> Observation
        step(action: Action) -> tuple[Observation, float, bool, dict]
        state() -> dict
    """

    TASKS = [
        "eligibility_screening",
        "lab_dose_management",
        "sae_triage",
    ]

    def __init__(self, task_id: str = "eligibility_screening", seed: int = 42):
        self.config = EnvConfig(task_id=task_id, seed=seed)
        self._grader = get_grader(task_id)
        self._cases: list[Observation] = []
        self._step_idx: int = 0
        self._episode_rewards: list[float] = []
        self._violation_count: int = 0
        self._missed_critical: int = 0
        self._done: bool = False

    # ── OpenEnv API ────────────────────────────────────────────────────────────

    def reset(self) -> Observation:
        """Return initial observation. Resets all episode state."""
        self._cases = generate_cases(
            self.config.task_id, seed=self.config.seed
        )
        self._step_idx = 0
        self._episode_rewards = []
        self._violation_count = 0
        self._missed_critical = 0
        self._done = False
        return self._cases[0]

    def step(self, action: Action) -> tuple[Observation | None, float, bool, dict]:
        """
        Process one action. Returns (next_obs, reward, done, info).
        reward is in [0.0, 1.0] (can be negative for harm penalties).
        done=True after last case in the shift.
        """
        if self._done:
            raise RuntimeError("Episode is done. Call reset() first.")

        current_case = self._cases[self._step_idx]
        breakdown: RewardBreakdown = self._grader(action, current_case)

        reward = float(breakdown.total)
        self._episode_rewards.append(reward)

        # Track violations
        if breakdown.harm_penalty > 0:
            self._violation_count += 1
            if breakdown.harm_penalty >= 0.20:
                self._missed_critical += 1

        self._step_idx += 1
        self._done = self._step_idx >= len(self._cases)

        next_obs = None if self._done else self._cases[self._step_idx]

        info = {
            "step": self._step_idx - 1,
            "patient_id": current_case.patient_id,
            "case_type": current_case.case_type,
            "reward_breakdown": breakdown.model_dump(),
            "cumulative_reward": round(sum(self._episode_rewards), 4),
            "mean_reward": round(
                sum(self._episode_rewards) / len(self._episode_rewards), 4
            ),
            "regulatory_violations": self._violation_count,
            "missed_critical_events": self._missed_critical,
            "episode_done": self._done,
        }

        return next_obs, reward, self._done, info

    def state(self) -> dict:
        """Return current environment state (serialisable)."""
        return EnvState(
            task_id=self.config.task_id,
            step=self._step_idx,
            total_cases=len(self._cases),
            done=self._done,
            cumulative_reward=round(sum(self._episode_rewards), 4),
            regulatory_violations=self._violation_count,
            missed_critical_events=self._missed_critical,
        ).model_dump()

    # ── Helpers ────────────────────────────────────────────────────────────────

    def current_observation(self) -> Observation | None:
        if self._done or not self._cases:
            return None
        return self._cases[self._step_idx]

    def episode_summary(self) -> dict:
        if not self._episode_rewards:
            return {}
        return {
            "task_id": self.config.task_id,
            "total_steps": len(self._episode_rewards),
            "mean_reward": round(
                sum(self._episode_rewards) / len(self._episode_rewards), 4
            ),
            "total_reward": round(sum(self._episode_rewards), 4),
            "regulatory_violations": self._violation_count,
            "missed_critical_events": self._missed_critical,
            "per_step_rewards": self._episode_rewards,
        }
