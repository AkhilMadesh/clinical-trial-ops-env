"""
ClinicalTrialOps-Env — Pydantic models
Observation, Action, Reward, State
"""
from __future__ import annotations
from typing import Literal, Optional
from pydantic import BaseModel, Field


# ── Observation ────────────────────────────────────────────────────────────────

class LabValues(BaseModel):
    ALT: Optional[float] = None          # U/L  (ULN 40)
    AST: Optional[float] = None          # U/L  (ULN 40)
    creatinine: Optional[float] = None   # mg/dL (ULN 1.2)
    WBC: Optional[float] = None          # 10^9/L (range 4-11)
    ANC: Optional[float] = None          # 10^9/L (ULN 7.5, lower limit concern <1.5)
    platelets: Optional[float] = None    # 10^9/L (range 150-400)
    hemoglobin: Optional[float] = None   # g/dL  (lower limit concern <8)
    troponin_I: Optional[float] = None   # ng/mL (ULN 0.04)
    QTc: Optional[float] = None          # ms    (concern >470 women, >450 men)
    bilirubin: Optional[float] = None    # mg/dL (ULN 1.0)
    eGFR: Optional[float] = None         # mL/min/1.73m2


class PatientData(BaseModel):
    age: int
    sex: Literal["M", "F"]
    diagnosis: str
    ecog_ps: int = Field(ge=0, le=5, description="ECOG performance status")
    prior_chemo_lines: int
    lab_values: LabValues
    medications: list[str] = []
    vitals: dict = {}
    medical_history: list[str] = []
    allergies: list[str] = []


class ProtocolRef(BaseModel):
    protocol_id: str
    version: str
    inclusion_criteria: list[str]
    exclusion_criteria: list[str]
    dose_modification_rules: dict
    sae_definitions: list[str]
    reporting_requirements: dict


class Observation(BaseModel):
    patient_id: str
    case_type: Literal[
        "eligibility_screen",
        "adverse_event",
        "protocol_deviation",
        "lab_review",
        "sae_report",
    ]
    patient_data: PatientData
    protocol_ref: ProtocolRef
    case_notes: str
    event_description: Optional[str] = None
    prior_actions: list[str] = []
    step_number: int
    shift_cases_remaining: int


# ── Action ─────────────────────────────────────────────────────────────────────

class Action(BaseModel):
    decision: Literal[
        "enroll",
        "screen_fail",
        "hold_pending_review",
        "dose_reduce_1_level",
        "dose_reduce_2_levels",
        "dose_hold_temporary",
        "dose_discontinue",
        "report_SAE",
        "report_non_SAE_AE",
        "protocol_deviation_minor",
        "protocol_deviation_major",
        "escalate_to_PI",
        "continue_no_action",
    ]
    rationale: str = Field(
        description="Clinical reasoning for this decision"
    )
    regulatory_citation: Optional[str] = Field(
        default=None,
        description="e.g. 'ICH E6 R2 Section 4.11' or 'FDA 21 CFR 312.32(c)'"
    )
    urgency: Literal["routine", "24h", "immediate"] = "routine"
    follow_up_action: Optional[str] = None
    notify_irb: bool = False
    notify_sponsor: bool = False


# ── Reward ─────────────────────────────────────────────────────────────────────

class RewardBreakdown(BaseModel):
    decision_score: float = 0.0
    citation_score: float = 0.0
    urgency_score: float = 0.0
    rationale_score: float = 0.0
    harm_penalty: float = 0.0
    total: float = 0.0
    feedback: str = ""


# ── State ──────────────────────────────────────────────────────────────────────

class EnvState(BaseModel):
    task_id: str
    step: int
    total_cases: int
    done: bool
    cumulative_reward: float
    regulatory_violations: int
    missed_critical_events: int
