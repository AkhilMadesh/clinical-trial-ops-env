"""
Grader — Task 2: Lab Deviation + Dose Management
Multi-component scoring: decision + urgency + citation.
"""
from __future__ import annotations
from env.models import Action, Observation, RewardBreakdown
from env.case_generator import TASK2_CASES

# Ground truth keyed by patient_id
GROUND_TRUTH = {
    pid: {
        "decision": decision,
        "urgency": urgency,
        "citation": citation,
        "rationale_key": rationale_key,
    }
    for pid, decision, urgency, citation, rationale_key, _, _ in TASK2_CASES
}

# Decisions that are safety-critical — wrong urgency carries a penalty
SAFETY_CRITICAL_DECISIONS = {
    "dose_hold_temporary",
    "dose_discontinue",
    "report_SAE",
    "escalate_to_PI",
}

# Adjacent decisions (partial credit)
ADJACENT_DECISIONS = {
    "dose_hold_temporary": {"dose_reduce_1_level", "escalate_to_PI"},
    "dose_reduce_1_level": {"dose_hold_temporary", "dose_reduce_2_levels"},
    "dose_reduce_2_levels": {"dose_reduce_1_level"},
    "dose_discontinue":    {"dose_hold_temporary", "report_SAE"},
    "report_SAE":          {"escalate_to_PI", "dose_discontinue"},
    "continue_no_action":  {"dose_reduce_1_level"},
    "escalate_to_PI":      {"report_SAE"},
}


def score(action: Action, obs: Observation) -> RewardBreakdown:
    pid = obs.patient_id
    gt = GROUND_TRUTH.get(pid, {})
    correct_decision = gt.get("decision", "")
    correct_urgency = gt.get("urgency", "routine")
    correct_citation = gt.get("citation", "")
    rationale_key = gt.get("rationale_key", "")

    agent_decision = action.decision
    agent_urgency = action.urgency

    # Decision scoring
    if agent_decision == correct_decision:
        decision_score = 0.40
    elif agent_decision in ADJACENT_DECISIONS.get(correct_decision, set()):
        decision_score = 0.20
    else:
        decision_score = 0.0

    # Urgency scoring
    urgency_map = {"routine": 0, "24h": 1, "immediate": 2}
    u_correct = urgency_map.get(correct_urgency, 0)
    u_agent = urgency_map.get(agent_urgency, 0)
    urgency_diff = abs(u_correct - u_agent)
    if urgency_diff == 0:
        urgency_score = 0.20
    elif urgency_diff == 1:
        urgency_score = 0.10
    else:
        urgency_score = 0.0

    # Penalty: under-urgent on safety-critical cases
    harm_penalty = 0.0
    if (correct_decision in SAFETY_CRITICAL_DECISIONS
            and u_agent < u_correct):
        harm_penalty = 0.10

    # Citation scoring (substring match on key terms)
    citation_score = 0.0
    if action.regulatory_citation:
        key_terms = [t for t in correct_citation.split() if len(t) > 3]
        matches = sum(
            1 for t in key_terms
            if t.lower() in action.regulatory_citation.lower()
        )
        citation_score = 0.30 * min(1.0, matches / max(1, len(key_terms) // 2))

    # Rationale score
    rationale_score = 0.0
    if action.rationale and rationale_key:
        key_words = [w for w in rationale_key.split() if len(w) > 3]
        hits = sum(1 for w in key_words if w.lower() in action.rationale.lower())
        rationale_score = 0.10 * min(1.0, hits / max(1, len(key_words) // 2))

    total = decision_score + urgency_score + citation_score + rationale_score - harm_penalty
    total = round(max(0.0, min(1.0, total)), 3)

    feedback = (
        f"Decision: {'correct' if agent_decision == correct_decision else f'expected {correct_decision}'}. "
        f"Urgency: {'correct' if urgency_diff == 0 else f'expected {correct_urgency}'}. "
        f"{'PENALTY: under-urgent on safety-critical event.' if harm_penalty > 0 else ''}"
    )

    return RewardBreakdown(
        decision_score=round(decision_score, 3),
        urgency_score=round(urgency_score, 3),
        citation_score=round(citation_score, 3),
        rationale_score=round(rationale_score, 3),
        harm_penalty=round(harm_penalty, 3),
        total=total,
        feedback=feedback,
    )
