"""
Grader — Task 3: Serious Adverse Event (SAE) Triage
Asymmetric penalties: missed SAE = -0.20, false SAE = -0.05.
Models real clinical risk of under vs over reporting.
"""
from __future__ import annotations
from env.models import Action, Observation, RewardBreakdown
from env.case_generator import TASK3_CASES

GROUND_TRUTH = {
    pid: {
        "is_sae": is_sae,
        "decision": decision,
        "urgency": urgency,
        "notify_pi": notify_pi,
        "citation": citation,
        "trap": trap,
    }
    for pid, is_sae, decision, urgency, notify_pi, citation, trap, _ in TASK3_CASES
}

SAE_DECISIONS = {"report_SAE", "escalate_to_PI"}
NON_SAE_DECISIONS = {"report_non_SAE_AE", "continue_no_action",
                     "protocol_deviation_minor", "protocol_deviation_major"}

URGENCY_RANK = {"routine": 0, "24h": 1, "immediate": 2}

ADJACENT_SAE = {
    "report_SAE":             {"escalate_to_PI"},
    "escalate_to_PI":         {"report_SAE"},
    "protocol_deviation_major": {"protocol_deviation_minor", "escalate_to_PI"},
    "protocol_deviation_minor": {"protocol_deviation_major", "continue_no_action"},
    "report_non_SAE_AE":      {"protocol_deviation_minor"},
    "continue_no_action":     {"report_non_SAE_AE"},
}


def score(action: Action, obs: Observation) -> RewardBreakdown:
    pid = obs.patient_id
    gt = GROUND_TRUTH.get(pid, {})
    is_sae = gt.get("is_sae", False)
    correct_decision = gt.get("decision", "")
    correct_urgency = gt.get("urgency", "routine")
    correct_notify_pi = gt.get("notify_pi", False)
    correct_citation = gt.get("citation", "")

    agent_decision = action.decision
    agent_is_sae = agent_decision in SAE_DECISIONS

    # SAE classification (30%)
    sae_classification_correct = is_sae == agent_is_sae
    if sae_classification_correct:
        sae_score = 0.30
    elif agent_decision in ADJACENT_SAE.get(correct_decision, set()):
        sae_score = 0.15
    else:
        sae_score = 0.0

    # Reportability / decision match (25%)
    if agent_decision == correct_decision:
        report_score = 0.25
    elif agent_decision in ADJACENT_SAE.get(correct_decision, set()):
        report_score = 0.12
    else:
        report_score = 0.0

    # Urgency window (20%)
    u_correct = URGENCY_RANK.get(correct_urgency, 0)
    u_agent = URGENCY_RANK.get(action.urgency, 0)
    diff = abs(u_correct - u_agent)
    if diff == 0:
        urgency_score = 0.20
    elif diff == 1:
        urgency_score = 0.10
    else:
        urgency_score = 0.0

    # PI escalation decision (15%)
    agent_notifies_pi = (
        action.notify_irb
        or action.notify_sponsor
        or action.decision == "escalate_to_PI"
    )
    escalation_score = 0.15 if agent_notifies_pi == correct_notify_pi else 0.0

    # Citation quality (10%) — partial keyword match
    citation_score = 0.0
    if action.regulatory_citation and correct_citation:
        key_terms = [t for t in correct_citation.split()
                     if len(t) > 3 and not t.startswith("—")]
        if key_terms:
            hits = sum(1 for t in key_terms
                       if t.lower() in action.regulatory_citation.lower())
            citation_score = 0.10 * min(1.0, hits / max(1, len(key_terms) // 2))

    # Penalties
    harm_penalty = 0.0
    false_positive_penalty = 0.0

    # Missed SAE — most serious failure
    if is_sae and not agent_is_sae:
        harm_penalty = 0.20

    # Missed critical urgency on confirmed SAE
    elif is_sae and agent_is_sae and correct_urgency == "immediate" and action.urgency == "routine":
        harm_penalty = 0.10

    # False SAE classification (over-reporting wastes resources but less dangerous)
    elif not is_sae and agent_is_sae:
        false_positive_penalty = 0.05

    subtotal = (sae_score + report_score + urgency_score
                + escalation_score + citation_score)
    total = round(max(-0.20, min(1.0, subtotal - harm_penalty - false_positive_penalty)), 3)

    feedback_parts = []
    if not sae_classification_correct:
        feedback_parts.append(
            f"SAE classification wrong: {'should be SAE' if is_sae else 'not an SAE'}."
        )
    if harm_penalty > 0:
        feedback_parts.append(f"HARM PENALTY -{harm_penalty}: missed/under-triaged critical SAE.")
    if false_positive_penalty > 0:
        feedback_parts.append(f"Over-report penalty -{false_positive_penalty}.")
    if not feedback_parts:
        feedback_parts.append("Correct SAE classification and triage.")

    return RewardBreakdown(
        decision_score=round(sae_score + report_score, 3),
        urgency_score=round(urgency_score, 3),
        rationale_score=round(escalation_score + citation_score, 3),
        harm_penalty=round(harm_penalty + false_positive_penalty, 3),
        total=total,
        feedback=" ".join(feedback_parts),
    )
