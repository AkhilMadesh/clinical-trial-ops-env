"""
Grader — Task 1: Protocol Eligibility Screening
Deterministic scoring against ground truth labels.
"""
from __future__ import annotations
from env.models import Action, Observation, RewardBreakdown
from env.case_generator import TASK1_CASES


# Ground truth map
GROUND_TRUTH = {pid: enroll for pid, enroll, _, _ in TASK1_CASES}


def score(action: Action, obs: Observation) -> RewardBreakdown:
    pid = obs.patient_id
    correct_enroll = GROUND_TRUTH.get(pid, True)
    agent_enroll = action.decision == "enroll"

    decision_correct = agent_enroll == correct_enroll

    # Full credit for correct decision
    if decision_correct:
        decision_score = 0.70
        # Bonus for non-empty rationale (0.20) and citation (0.10)
        rationale_score = 0.20 if action.rationale and len(action.rationale) > 10 else 0.10
        citation_score = 0.10 if action.regulatory_citation else 0.0
        total = decision_score + rationale_score + citation_score
        feedback = f"Correct: patient {pid} should {'enroll' if correct_enroll else 'screen fail'}."
    else:
        # Partial credit: correct rationale but wrong conclusion
        rationale_score = 0.0
        citation_score = 0.0
        # Check if rationale references the correct disqualifying criterion
        fail_reason = next((r for p, e, r, _ in TASK1_CASES if p == pid), "")
        partial = (
            fail_reason
            and action.rationale
            and any(kw.lower() in action.rationale.lower()
                    for kw in fail_reason.split()[:3] if len(kw) > 3)
        )
        decision_score = 0.30 if partial else 0.0
        total = decision_score
        feedback = (
            f"Incorrect decision for {pid}. "
            f"Correct: {'enroll' if correct_enroll else 'screen fail'}. "
            f"{'Partial credit: reasoning mentioned relevant criterion.' if partial else ''}"
        )

    return RewardBreakdown(
        decision_score=round(decision_score, 3),
        rationale_score=round(rationale_score, 3),
        citation_score=round(citation_score, 3),
        total=round(min(1.0, total), 3),
        feedback=feedback,
    )
