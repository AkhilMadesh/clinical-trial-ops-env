from env.graders.eligibility import score as score_eligibility
from env.graders.lab_dose import score as score_lab_dose
from env.graders.sae_triage import score as score_sae


def get_grader(task_id: str):
    mapping = {
        "eligibility_screening": score_eligibility,
        "lab_dose_management": score_lab_dose,
        "sae_triage": score_sae,
    }
    if task_id not in mapping:
        raise ValueError(f"Unknown task_id: {task_id}")
    return mapping[task_id]
