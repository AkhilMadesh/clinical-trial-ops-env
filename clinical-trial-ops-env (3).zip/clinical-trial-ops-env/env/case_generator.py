"""
ClinicalTrialOps-Env — Case Generator
Generates reproducible synthetic patient cases using numpy seeded RNG.
All cases are entirely fictional.
"""
from __future__ import annotations
import numpy as np
from env.models import Observation, PatientData, LabValues, ProtocolRef
from env.protocol_db import PROTOCOL


def _make_protocol_ref() -> ProtocolRef:
    return ProtocolRef(**{k: PROTOCOL[k] for k in [
        "protocol_id", "version", "inclusion_criteria",
        "exclusion_criteria", "dose_modification_rules",
        "sae_definitions", "reporting_requirements",
    ]})


# ── Task 1: Eligibility Screening ─────────────────────────────────────────────

TASK1_CASES = [
    # (patient_id, should_enroll, reason_if_fail, data_override)
    ("PT-001", True, None, {
        "age": 58, "sex": "M", "diagnosis": "NSCLC adenocarcinoma",
        "ecog_ps": 1, "prior_chemo_lines": 2,
        "labs": {"ALT": 32, "AST": 28, "creatinine": 1.0,
                 "ANC": 2.1, "platelets": 180, "hemoglobin": 10.5, "QTc": 430},
        "meds": ["ondansetron", "omeprazole"],
        "notes": "58M NSCLC adeno, 2L prior chemo, labs WNL, no prior EGFR therapy.",
    }),
    ("PT-002", False, "ECOG PS 3 (exceeds limit of 2)", {
        "age": 67, "sex": "F", "diagnosis": "NSCLC squamous",
        "ecog_ps": 3, "prior_chemo_lines": 1,
        "labs": {"ALT": 25, "AST": 22, "creatinine": 1.1,
                 "ANC": 2.5, "platelets": 210, "hemoglobin": 11.0, "QTc": 445},
        "meds": ["dexamethasone"],
        "notes": "67F NSCLC squamous, ECOG PS 3, patient bedridden >50% of day.",
    }),
    ("PT-003", False, "Prior EGFR inhibitor (erlotinib) — excluded", {
        "age": 52, "sex": "F", "diagnosis": "NSCLC adenocarcinoma",
        "ecog_ps": 1, "prior_chemo_lines": 2,
        "labs": {"ALT": 30, "AST": 27, "creatinine": 0.9,
                 "ANC": 3.0, "platelets": 195, "hemoglobin": 12.1, "QTc": 455},
        "meds": ["erlotinib_history"],
        "notes": "52F NSCLC adeno. Previously received erlotinib for 8 months.",
    }),
    ("PT-004", True, None, {
        "age": 71, "sex": "M", "diagnosis": "NSCLC adenocarcinoma",
        "ecog_ps": 0, "prior_chemo_lines": 1,
        "labs": {"ALT": 38, "AST": 35, "creatinine": 1.2,
                 "ANC": 1.8, "platelets": 155, "hemoglobin": 9.5, "QTc": 448},
        "meds": ["aspirin", "metformin"],
        "notes": "71M, 1L prior chemo with carboplatin/pemetrexed. Hgb 9.5 (>= 9 threshold).",
    }),
    ("PT-005", False, "ANC 1.2 x10^9/L — below threshold of 1.5", {
        "age": 61, "sex": "M", "diagnosis": "NSCLC squamous",
        "ecog_ps": 2, "prior_chemo_lines": 2,
        "labs": {"ALT": 29, "AST": 31, "creatinine": 1.0,
                 "ANC": 1.2, "platelets": 130, "hemoglobin": 10.0, "QTc": 440},
        "meds": ["G-CSF_recent"],
        "notes": "61M, ANC 1.2 — borderline myelosuppression from recent chemo.",
    }),
    ("PT-006", False, "Concurrent clarithromycin (strong CYP3A4 inhibitor)", {
        "age": 55, "sex": "F", "diagnosis": "NSCLC adenocarcinoma",
        "ecog_ps": 1, "prior_chemo_lines": 1,
        "labs": {"ALT": 22, "AST": 20, "creatinine": 0.8,
                 "ANC": 2.8, "platelets": 220, "hemoglobin": 12.5, "QTc": 438},
        "meds": ["clarithromycin", "azithromycin_alternate_mentioned"],
        "notes": "55F on clarithromycin for bronchitis. Active CYP3A4 inhibition.",
    }),
    ("PT-007", True, None, {
        "age": 48, "sex": "F", "diagnosis": "NSCLC adenocarcinoma",
        "ecog_ps": 0, "prior_chemo_lines": 3,
        "labs": {"ALT": 18, "AST": 16, "creatinine": 0.7,
                 "ANC": 3.5, "platelets": 280, "hemoglobin": 13.2, "QTc": 442},
        "meds": ["ondansetron"],
        "notes": "48F, 3L prior platinum-based therapy. All labs excellent. QTc 442 < 470 threshold.",
    }),
    ("PT-008", False, "QTc 482ms exceeds 470ms female threshold", {
        "age": 63, "sex": "F", "diagnosis": "NSCLC squamous",
        "ecog_ps": 1, "prior_chemo_lines": 2,
        "labs": {"ALT": 35, "AST": 30, "creatinine": 1.1,
                 "ANC": 2.0, "platelets": 175, "hemoglobin": 10.8, "QTc": 482},
        "meds": ["ondansetron", "haloperidol"],
        "notes": "63F QTc 482ms. On haloperidol for nausea management.",
    }),
    ("PT-009", False, "creatinine 2.1 mg/dL (>1.5 ULN) AND eGFR 38 (<50)", {
        "age": 74, "sex": "M", "diagnosis": "NSCLC adenocarcinoma",
        "ecog_ps": 2, "prior_chemo_lines": 1,
        "labs": {"ALT": 28, "AST": 24, "creatinine": 2.1,
                 "ANC": 1.9, "platelets": 190, "hemoglobin": 9.8, "QTc": 441, "eGFR": 38},
        "meds": ["lisinopril", "furosemide"],
        "notes": "74M CKD stage 3b. creatinine 2.1, eGFR 38 — both criteria fail.",
    }),
    ("PT-010", True, None, {
        "age": 44, "sex": "M", "diagnosis": "NSCLC adenocarcinoma",
        "ecog_ps": 1, "prior_chemo_lines": 2,
        "labs": {"ALT": 15, "AST": 18, "creatinine": 0.9,
                 "ANC": 4.2, "platelets": 310, "hemoglobin": 14.1, "QTc": 435},
        "meds": ["vitamin_D", "omeprazole"],
        "notes": "44M, excellent performance status, all labs well within normal limits.",
    }),
]


def generate_task1_cases(rng: np.random.Generator) -> list[Observation]:
    proto = _make_protocol_ref()
    cases = []
    for i, (pid, _, reason, data) in enumerate(TASK1_CASES):
        labs = LabValues(**data["labs"])
        patient = PatientData(
            age=data["age"], sex=data["sex"],
            diagnosis=data["diagnosis"],
            ecog_ps=data["ecog_ps"],
            prior_chemo_lines=data["prior_chemo_lines"],
            lab_values=labs,
            medications=data["meds"],
        )
        obs = Observation(
            patient_id=pid,
            case_type="eligibility_screen",
            patient_data=patient,
            protocol_ref=proto,
            case_notes=data["notes"],
            step_number=i,
            shift_cases_remaining=len(TASK1_CASES) - i - 1,
        )
        cases.append(obs)
    return cases


# ── Task 2: Lab Deviation + Dose Management ────────────────────────────────────

TASK2_CASES = [
    # (pid, correct_decision, urgency, citation, rationale_key, labs, notes)
    ("LAB-001", "dose_hold_temporary", "24h",
     "Protocol Section 6.3 — Hematologic Toxicity Grade 3",
     "ANC 0.8 x10^9/L = Grade 3 neutropenia",
     {"ANC": 0.8, "platelets": 145, "hemoglobin": 10.2, "ALT": 28, "AST": 25},
     "Day 14 labs: ANC dropped to 0.8. Patient reports mild fatigue."),

    ("LAB-002", "continue_no_action", "routine",
     "Protocol Section 6.2 — Hepatotoxicity",
     "ALT 68 = 1.7x ULN — Grade 1, no action required per protocol",
     {"ALT": 68, "AST": 55, "creatinine": 0.9, "ANC": 2.1, "platelets": 210},
     "Cycle 2 Day 1 labs. ALT 68 (ULN 40). Asymptomatic. No prior liver disease."),

    ("LAB-003", "dose_hold_temporary", "24h",
     "Protocol Section 6.3 — Hematologic Toxicity, Platelets Grade 3",
     "Platelets 38 x10^9/L = Grade 3 thrombocytopenia",
     {"ANC": 1.9, "platelets": 38, "hemoglobin": 9.1, "ALT": 22, "AST": 19},
     "Cycle 3 Day 7 check. Platelets fell from 175 to 38. No active bleeding."),

    ("LAB-004", "dose_reduce_1_level", "24h",
     "Protocol Section 6.2 — Hepatotoxicity Grade 3",
     "ALT 215 = 5.4x ULN — Grade 3; dose reduce 1 level",
     {"ALT": 215, "AST": 188, "creatinine": 1.0, "ANC": 2.3, "platelets": 190},
     "Cycle 2 Day 21. ALT/AST markedly elevated. Patient reports RUQ discomfort."),

    ("LAB-005", "dose_hold_temporary", "immediate",
     "Protocol Section 6.4 — QTc Prolongation",
     "QTc 508ms > 500ms threshold — immediate hold and cardiology consult",
     {"QTc": 508, "ALT": 30, "creatinine": 0.8, "ANC": 2.5, "platelets": 200},
     "ECG obtained for palpitations. QTc 508ms. No electrolyte abnormalities noted."),

    ("LAB-006", "dose_discontinue", "immediate",
     "Protocol Section 6.2 — Hepatotoxicity Grade 4",
     "ALT 950 = 23.75x ULN — Grade 4; permanent discontinuation + SAE report",
     {"ALT": 950, "AST": 820, "creatinine": 1.1, "ANC": 2.0, "platelets": 175},
     "Patient admitted to ER. Jaundice, RUQ pain. ALT 950, AST 820. Drug-induced liver injury suspected."),

    ("LAB-007", "continue_no_action", "routine",
     "No protocol action required — all values within acceptable range",
     "All labs Grade 0-1, no dose modification criteria met",
     {"ALT": 45, "AST": 38, "creatinine": 1.1, "ANC": 2.8, "platelets": 195, "hemoglobin": 11.5},
     "Routine Cycle 4 Day 1. All values stable. ALT 45 = 1.1x ULN (Grade 1, no action)."),

    ("LAB-008", "dose_hold_temporary", "immediate",
     "Protocol Section 6.3 — Hematologic Grade 4 Neutropenia",
     "ANC 0.3 x10^9/L = Grade 4 — immediate hold, febrile neutropenia precautions",
     {"ANC": 0.3, "platelets": 85, "hemoglobin": 8.1, "ALT": 25, "AST": 22},
     "Patient called with fever 38.4°C. ANC 0.3. Admitted for IV antibiotics."),

    ("LAB-009", "dose_reduce_1_level", "24h",
     "Protocol Section 6.5 — Renal Toxicity Grade 2",
     "Creatinine 1.9 mg/dL = 1.58x ULN — dose reduce 1 level per renal criteria",
     {"creatinine": 1.9, "eGFR": 48, "ALT": 26, "AST": 24, "ANC": 2.2, "platelets": 180},
     "Creatinine rising trend: 1.0 → 1.4 → 1.9 over 6 weeks. eGFR 48 (below 50 threshold)."),

    ("LAB-010", "continue_no_action", "routine",
     "No protocol action required",
     "QTc 462ms — below 470ms female threshold, no action",
     {"QTc": 462, "ALT": 31, "AST": 28, "creatinine": 0.9, "ANC": 3.1, "platelets": 220},
     "Female patient. Routine ECG QTc 462ms. Threshold for concern in females is >470ms."),

    ("LAB-011", "report_SAE", "immediate",
     "FDA 21 CFR 312.32(c) — SAE: hospitalization",
     "Grade 4 hepatotoxicity + hospitalization = SAE; 24h sponsor notification + 7-day FDA report",
     {"ALT": 1100, "AST": 950, "bilirubin": 8.5, "creatinine": 1.2, "ANC": 1.8},
     "Patient hospitalized with drug-induced liver failure. Bilirubin 8.5, ALT 1100. ICU admission."),

    ("LAB-012", "dose_hold_temporary", "24h",
     "Protocol Section 6.3 — Hematologic Grade 3, Hemoglobin",
     "Hemoglobin 7.2 g/dL — Grade 3 anemia; hold and evaluate for transfusion",
     {"hemoglobin": 7.2, "ANC": 2.1, "platelets": 165, "ALT": 28, "creatinine": 0.9},
     "Patient reports dyspnea on exertion, fatigue. Hgb dropped from 10.5 to 7.2 over 2 weeks."),
]


def generate_task2_cases(rng: np.random.Generator) -> list[Observation]:
    proto = _make_protocol_ref()
    cases = []
    for i, (pid, decision, urgency, citation, rationale, labs_dict, notes) in enumerate(TASK2_CASES):
        labs = LabValues(**labs_dict)
        patient = PatientData(
            age=int(rng.integers(45, 75)),
            sex=rng.choice(["M", "F"]),
            diagnosis="NSCLC adenocarcinoma",
            ecog_ps=int(rng.integers(0, 3)),
            prior_chemo_lines=int(rng.integers(1, 4)),
            lab_values=labs,
            medications=["velitinib 150mg QD"],
        )
        obs = Observation(
            patient_id=pid,
            case_type="lab_review",
            patient_data=patient,
            protocol_ref=proto,
            case_notes=notes,
            step_number=i,
            shift_cases_remaining=len(TASK2_CASES) - i - 1,
        )
        cases.append(obs)
    return cases


# ── Task 3: SAE Triage ──────────────────────────────────────────────────────────

TASK3_CASES = [
    # (pid, is_SAE, correct_decision, urgency, notify_PI, citation, trap_type, notes)
    ("SAE-001", True, "report_SAE", "immediate", True,
     "FDA 21 CFR 312.32(c)(1)(i) — life-threatening SUSAR",
     None,
     "Patient presents with acute chest pain, troponin 2.8 ng/mL (ULN 0.04), ST elevation on ECG. Admitted to cardiac ICU. No prior cardiac history."),

    ("SAE-002", False, "report_non_SAE_AE", "routine", False,
     "ICH E2A — Grade 2 AE, expected, not serious",
     "looks_serious",
     "Patient reports severe nausea/vomiting for 3 days. Dehydrated, received IV fluids in clinic (not admitted). No hospitalization. Expected AE per IB."),

    ("SAE-003", True, "report_SAE", "24h", True,
     "FDA 21 CFR 312.32(c)(1)(ii) — SAE: hospitalization",
     None,
     "Patient admitted for pneumonia. Fever 39.2°C, infiltrates on CT. ANC 0.6 (febrile neutropenia). Hospitalized 5 days."),

    ("SAE-004", False, "protocol_deviation_minor", "routine", False,
     "ICH E6 R2 Section 4.5 — minor protocol deviation",
     "deviation_not_SAE",
     "Cycle 3 Day 1 labs drawn on Day 2 instead of Day 1 due to patient scheduling conflict. Labs all normal. No patient harm."),

    ("SAE-005", True, "report_SAE", "immediate", True,
     "FDA 21 CFR 312.32(c)(1)(i) — life-threatening: status epilepticus",
     None,
     "Patient brought to ER by family with new-onset seizure activity. Status epilepticus, intubated. Brain MRI ordered. No prior seizure history. On study drug."),

    ("SAE-006", False, "continue_no_action", "routine", False,
     "No regulatory action — Grade 1 expected AE",
     "trap_borderline",
     "Patient reports mild rash on chest, Grade 1. Expected dermatologic AE per investigator brochure Section 5. No treatment needed. Documented in source."),

    ("SAE-007", True, "report_SAE", "24h", True,
     "FDA 21 CFR 312.32(c)(1)(ii) — SAE: significant disability",
     None,
     "Patient reports sudden vision loss in left eye (central retinal artery occlusion confirmed by ophthalmology). Permanent visual impairment."),

    ("SAE-008", False, "report_non_SAE_AE", "routine", False,
     "ICH E2A — Grade 3 AE, not meeting SAE criteria (no hospitalization, not life-threatening)",
     "grade3_not_SAE",
     "Grade 3 fatigue and anorexia. Patient lost 8% body weight. Managed as outpatient with nutritional support. Not hospitalized, not life-threatening."),

    ("SAE-009", True, "report_SAE", "immediate", True,
     "FDA 21 CFR 312.32(c)(1)(i) — fatal SAE",
     None,
     "Patient found unresponsive at home. Brought to ER, pronounced deceased. Cause unknown pending autopsy. Last dose of study drug 36 hours prior."),

    ("SAE-010", False, "protocol_deviation_major", "routine", True,
     "ICH E6 R2 Section 4.5 — major protocol deviation: ineligible patient enrolled",
     "deviation_not_SAE",
     "During record audit found patient had prior erlotinib therapy (exclusion criterion). Patient was incorrectly enrolled. No SAE occurred but major protocol deviation."),

    ("SAE-011", True, "report_SAE", "24h", True,
     "FDA 21 CFR 312.32(c)(1)(ii) — SAE: important medical event (anaphylaxis)",
     None,
     "30 minutes after study drug administration, patient develops urticaria, angioedema, hypotension (BP 78/45). IV epinephrine administered. Anaphylaxis confirmed."),

    ("SAE-012", False, "report_non_SAE_AE", "routine", False,
     "ICH E2A — Grade 2 diarrhea, expected toxicity, not meeting SAE criteria",
     "looks_serious",
     "Persistent Grade 2 diarrhea for 10 days. Patient uncomfortable but managing at home. No dehydration, no hospitalization. Expected velitinib toxicity."),

    ("SAE-013", True, "report_SAE", "immediate", True,
     "FDA 21 CFR 312.32(c)(1)(i) — life-threatening hemorrhage",
     None,
     "Patient admitted with massive hemoptysis, 600mL blood. Intubated and transferred to ICU. Hemoglobin 5.8 g/dL. Emergency bronchoscopy performed."),

    ("SAE-014", False, "continue_no_action", "routine", False,
     "Grade 1 expected AE — document only",
     "trap_urgency",
     "Patient mentions mild headache (Grade 1) at routine visit. Denies fever, neurologic symptoms. BP normal. Expected AE per IB. No action required beyond documentation."),

    ("SAE-015", True, "escalate_to_PI", "immediate", True,
     "FDA 21 CFR 312.32 — possible SAE, uncertain causality, requires PI medical judgment",
     None,
     "Patient reports 3-day history of confusion and memory problems. Family concerned. MRI not yet done. Could be CNS metastasis progression or drug effect. PI must evaluate urgently."),
]


def generate_task3_cases(rng: np.random.Generator) -> list[Observation]:
    proto = _make_protocol_ref()
    cases = []
    for i, (pid, is_sae, decision, urgency, notify_pi, citation, trap, notes) in enumerate(TASK3_CASES):
        labs = LabValues(
            ALT=float(rng.integers(15, 80)),
            AST=float(rng.integers(12, 75)),
            creatinine=round(float(rng.uniform(0.7, 1.4)), 1),
        )
        patient = PatientData(
            age=int(rng.integers(45, 80)),
            sex=rng.choice(["M", "F"]),
            diagnosis="NSCLC adenocarcinoma",
            ecog_ps=int(rng.integers(0, 3)),
            prior_chemo_lines=int(rng.integers(1, 4)),
            lab_values=labs,
            medications=["velitinib 150mg QD"],
        )
        obs = Observation(
            patient_id=pid,
            case_type="sae_report" if is_sae else "adverse_event",
            patient_data=patient,
            protocol_ref=proto,
            case_notes=notes,
            event_description=notes,
            step_number=i,
            shift_cases_remaining=len(TASK3_CASES) - i - 1,
        )
        cases.append(obs)
    return cases


# ── Entry point ────────────────────────────────────────────────────────────────

def generate_cases(task_id: str, seed: int = 42) -> list[Observation]:
    rng = np.random.default_rng(seed)
    if task_id == "eligibility_screening":
        return generate_task1_cases(rng)
    elif task_id == "lab_dose_management":
        return generate_task2_cases(rng)
    elif task_id == "sae_triage":
        return generate_task3_cases(rng)
    else:
        raise ValueError(f"Unknown task_id: {task_id}")
